AOS.init({
    duration: 1500,
  })


  $(function() {
    $('nav a[href^="/' + location.pathname.split("/")[1] + '"]').addClass('active');
  });